/**
 * NidusCare Cloud Functions - Enhanced Version
 * 
 * Melhorias implementadas:
 * - Tratamento robusto de erros com try-catch
 * - Logging estruturado e detalhado
 * - Validações de entrada
 * - Otimizações de performance
 * - Retry logic para operações críticas
 * - Rate limiting
 * - Caching inteligente
 * - Segurança aprimorada
 */

const { onCall, onRequest } = require("firebase-functions/v2/https");
const { onDocumentUpdated, onDocumentWritten } = require("firebase-functions/v2/firestore");
const { onSchedule } = require("firebase-functions/v2/scheduler");
const { logger } = require("firebase-functions");
const admin = require("firebase-admin");
const { VertexAI } = require("@google-cloud/vertexai");
const { HttpsError } = require("firebase-functions/v2/https");
const { onMessagePublished } = require("firebase-functions/v2/pubsub");
const { google } = require("googleapis");

const ANDROID_PACKAGE_NAME = "com.developersbeeh.medcontrol";

// Inicializar Firebase Admin
admin.initializeApp();

// Cache em memória para reduzir chamadas ao Firestore
const cache = new Map();
const CACHE_TTL = 5 * 60 * 1000; // 5 minutos

// Rate limiting map
const rateLimitMap = new Map();

// ============================================================================
// UTILITÁRIOS DE ERRO E LOGGING
// ============================================================================

/**
 * Classe customizada para erros da aplicação
 */
class AppError extends Error {
    constructor(code, message, details = {}) {
        super(message);
        this.code = code;
        this.details = details;
        this.name = 'AppError';
    }
}

/**
 * Logger estruturado com contexto
 */
const structuredLogger = {
    info: (message, context = {}) => {
        logger.info(message, { ...context, timestamp: new Date().toISOString() });
    },
    warn: (message, context = {}) => {
        logger.warn(message, { ...context, timestamp: new Date().toISOString() });
    },
    error: (message, error, context = {}) => {
        logger.error(message, {
            ...context,
            error: {
                message: error.message,
                stack: error.stack,
                code: error.code
            },
            timestamp: new Date().toISOString()
        });
    }
};

/**
 * Wrapper para tratamento de erros em funções async
 */
function asyncErrorHandler(fn) {
    return async (...args) => {
        try {
            return await fn(...args);
        } catch (error) {
            structuredLogger.error('Erro não tratado na função', error, {
                function: fn.name,
                args: JSON.stringify(args)
            });
            
            if (error instanceof HttpsError) {
                throw error;
            }
            
            if (error instanceof AppError) {
                throw new HttpsError(error.code, error.message, error.details);
            }
            
            throw new HttpsError('internal', 'Erro interno do servidor', {
                originalError: error.message
            });
        }
    };
}

/**
 * Retry logic para operações que podem falhar temporariamente
 */
async function retryOperation(operation, maxRetries = 3, delay = 1000) {
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
        try {
            return await operation();
        } catch (error) {
            if (attempt === maxRetries) {
                throw error;
            }
            structuredLogger.warn(`Tentativa ${attempt} falhou, tentando novamente...`, {
                error: error.message,
                nextAttemptIn: delay * attempt
            });
            await new Promise(resolve => setTimeout(resolve, delay * attempt));
        }
    }
}

// ============================================================================
// VALIDAÇÕES
// ============================================================================

/**
 * Validador de entrada genérico
 */
const validators = {
    isString: (value, fieldName) => {
        if (typeof value !== 'string') {
            throw new AppError('invalid-argument', `${fieldName} deve ser uma string`);
        }
    },
    
    isNumber: (value, fieldName) => {
        if (typeof value !== 'number' || isNaN(value)) {
            throw new AppError('invalid-argument', `${fieldName} deve ser um número válido`);
        }
    },
    
    isBoolean: (value, fieldName) => {
        if (typeof value !== 'boolean') {
            throw new AppError('invalid-argument', `${fieldName} deve ser um booleano`);
        }
    },
    
    isArray: (value, fieldName) => {
        if (!Array.isArray(value)) {
            throw new AppError('invalid-argument', `${fieldName} deve ser um array`);
        }
    },
    
    isNotEmpty: (value, fieldName) => {
        if (!value || (typeof value === 'string' && value.trim() === '')) {
            throw new AppError('invalid-argument', `${fieldName} não pode estar vazio`);
        }
    },
    
    isValidDate: (value, fieldName) => {
        const date = new Date(value);
        if (isNaN(date.getTime())) {
            throw new AppError('invalid-argument', `${fieldName} deve ser uma data válida`);
        }
    },
    
    isValidEmail: (value, fieldName) => {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(value)) {
            throw new AppError('invalid-argument', `${fieldName} deve ser um email válido`);
        }
    },
    
    isInRange: (value, min, max, fieldName) => {
        if (value < min || value > max) {
            throw new AppError('invalid-argument', `${fieldName} deve estar entre ${min} e ${max}`);
        }
    }
};

/**
 * Validar autenticação do usuário
 */
function validateAuth(context) {
    if (!context.auth) {
        throw new HttpsError('unauthenticated', 'Usuário não autenticado');
    }
    return context.auth.uid;
}

/**
 * Validar se usuário é premium
 */
async function validatePremiumUser(userId) {
    const userDoc = await admin.firestore().collection('users').doc(userId).get();
    if (!userDoc.exists) {
        throw new AppError('not-found', 'Usuário não encontrado');
    }
    
    const userData = userDoc.data();
    if (!userData.premium) {
        throw new AppError('permission-denied', 'Esta funcionalidade requer assinatura premium');
    }
    
    return userData;
}

// ============================================================================
// CACHE
// ============================================================================

/**
 * Obter valor do cache
 */
function getCached(key) {
    const cached = cache.get(key);
    if (!cached) return null;
    
    if (Date.now() - cached.timestamp > CACHE_TTL) {
        cache.delete(key);
        return null;
    }
    
    return cached.value;
}

/**
 * Salvar no cache
 */
function setCache(key, value) {
    cache.set(key, {
        value,
        timestamp: Date.now()
    });
}

/**
 * Limpar cache
 */
function clearCache(pattern) {
    if (pattern) {
        for (const key of cache.keys()) {
            if (key.includes(pattern)) {
                cache.delete(key);
            }
        }
    } else {
        cache.clear();
    }
}

// ============================================================================
// RATE LIMITING
// ============================================================================

/**
 * Verificar rate limit
 */
function checkRateLimit(userId, action, maxRequests = 10, windowMs = 60000) {
    const key = `${userId}:${action}`;
    const now = Date.now();
    const userRequests = rateLimitMap.get(key) || [];
    
    // Remover requisições antigas
    const recentRequests = userRequests.filter(timestamp => now - timestamp < windowMs);
    
    if (recentRequests.length >= maxRequests) {
        throw new HttpsError('resource-exhausted', 
            `Limite de requisições excedido. Tente novamente em ${Math.ceil((windowMs - (now - recentRequests[0])) / 1000)} segundos`
        );
    }
    
    recentRequests.push(now);
    rateLimitMap.set(key, recentRequests);
}

// ============================================================================
// AUTENTICAÇÃO GOOGLE PLAY
// ============================================================================

let isPlayApiInitialized = false;
let auth;

async function initGooglePlayPublisher() {
    if (isPlayApiInitialized) {
        return;
    }
    
    structuredLogger.info("🔑 Autenticando com a API do Google Play Developer...");
    
    try {
        if (!auth) {
            auth = new google.auth.GoogleAuth({
                scopes: ["https://www.googleapis.com/auth/androidpublisher"],
            });
        }
        
        const authClient = await auth.getClient();
        google.options({ auth: authClient });
        isPlayApiInitialized = true;
        
        structuredLogger.info("✅ API do Google Play Developer autenticada com sucesso.");
    } catch (error) {
        structuredLogger.error("❌ Falha ao autenticar com a API do Google Play", error);
        throw new AppError('internal', "Não foi possível inicializar o cliente da Google Play API.");
    }
}

const publisher = google.androidpublisher("v3");

// ============================================================================
// FUNÇÕES AUXILIARES DE DATA
// ============================================================================

/**
 * Converter entrada de data para UTC
 */
const getUTCDate = (dateInput) => {
    try {
        if (!dateInput) {
            throw new Error('Data inválida: entrada vazia');
        }
        
        if (typeof dateInput === 'string' && dateInput.includes('-')) {
            const parts = dateInput.split('-').map(Number);
            if (parts.length !== 3 || parts.some(isNaN)) {
                throw new Error('Formato de data inválido');
            }
            return new Date(Date.UTC(parts[0], parts[1] - 1, parts[2]));
        }
        
        const d = new Date(dateInput);
        if (isNaN(d.getTime())) {
            throw new Error('Data inválida');
        }
        
        return new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate()));
    } catch (error) {
        structuredLogger.error('Erro ao converter data', error, { dateInput });
        throw new AppError('invalid-argument', 'Formato de data inválido', { dateInput });
    }
};

/**
 * Verificar se é dia de medicamento
 */
const isMedicationDay = (med, date) => {
    try {
        if (!med || !med.dataInicioTratamentoString) {
            return false;
        }
        
        const treatmentStartUTC = getUTCDate(med.dataInicioTratamentoString);
        const dateUTC = getUTCDate(date);
        
        if (dateUTC < treatmentStartUTC) return false;
        
        switch (med.frequenciaTipo) {
            case "DIARIA":
                return true;
                
            case "SEMANAL":
                if (!med.diasSemana || !Array.isArray(med.diasSemana)) {
                    return false;
                }
                const jsDayOfWeek = dateUTC.getUTCDay();
                const appDayOfWeek = jsDayOfWeek === 0 ? 7 : jsDayOfWeek;
                return med.diasSemana.includes(appDayOfWeek);
                
            case "INTERVALO_DIAS":
                if (!med.frequenciaValor || med.frequenciaValor <= 0) {
                    return false;
                }
                const diffTime = dateUTC.getTime() - treatmentStartUTC.getTime();
                const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
                return diffDays % med.frequenciaValor === 0;
                
            default:
                return true;
        }
    } catch (error) {
        structuredLogger.error('Erro ao verificar dia de medicamento', error, { 
            medicationId: med?.id,
            date 
        });
        return false;
    }
};


/**
 * Calcular doses esperadas para um medicamento em um período
 */
const calculateExpectedDosesForMedication = (med, periodStart, periodEnd) => {
    try {
        // Validações
        if (!med) {
            throw new Error('Medicamento inválido');
        }
        
        if (med.isUsoEsporadico || !med.horarios || med.horarios.length === 0) {
            return 0;
        }
        
        const treatmentStart = getUTCDate(med.dataInicioTratamentoString);
        let treatmentEnd = getUTCDate(periodEnd);
        
        // Calcular fim do tratamento se não for uso contínuo
        if (!med.isUsoContinuo && med.duracaoDias > 0) {
            const end = new Date(treatmentStart);
            end.setUTCDate(end.getUTCDate() + med.duracaoDias - 1);
            treatmentEnd = end;
        }
        
        let effectiveStart = new Date(treatmentStart > periodStart ? treatmentStart : periodStart);
        let effectiveEnd = new Date(treatmentEnd < periodEnd ? treatmentEnd : periodEnd);
        
        if (effectiveStart > effectiveEnd) {
            return 0;
        }
        
        let totalExpected = 0;
        let currentDate = new Date(effectiveStart);
        
        while (currentDate <= effectiveEnd) {
            if (isMedicationDay(med, currentDate)) {
                // Tratamento especial para o primeiro dia
                if (currentDate.getTime() === treatmentStart.getTime() && 
                    med.dataCriacao && 
                    typeof med.dataCriacao === 'string') {
                    
                    const creationDateTime = new Date(med.dataCriacao);
                    if (!isNaN(creationDateTime.getTime())) {
                        const creationTimeInMinutes = creationDateTime.getUTCHours() * 60 + 
                                                     creationDateTime.getUTCMinutes();
                        
                        med.horarios.forEach(horarioStr => {
                            const [hour, minute] = horarioStr.split(':').map(Number);
                            const horarioInMinutes = hour * 60 + minute;
                            
                            if (horarioInMinutes >= creationTimeInMinutes) {
                                totalExpected++;
                            }
                        });
                    } else {
                        totalExpected += med.horarios.length;
                    }
                } else {
                    totalExpected += med.horarios.length;
                }
            }
            currentDate.setUTCDate(currentDate.getUTCDate() + 1);
        }
        
        return totalExpected;
    } catch (error) {
        structuredLogger.error('Erro ao calcular doses esperadas', error, {
            medicationId: med?.id,
            periodStart,
            periodEnd
        });
        return 0;
    }
};

/**
 * Calcular doses esperadas para múltiplos medicamentos
 */
const calculateExpectedDosesForPeriod = (medicamentos, startDate, endDate) => {
    try {
        if (!Array.isArray(medicamentos)) {
            throw new Error('Lista de medicamentos inválida');
        }
        
        let totalExpected = 0;
        const start = getUTCDate(startDate);
        const end = getUTCDate(endDate);
        
        medicamentos.forEach(med => {
            totalExpected += calculateExpectedDosesForMedication(med, start, end);
        });
        
        return totalExpected;
    } catch (error) {
        structuredLogger.error('Erro ao calcular doses para período', error, {
            medicationCount: medicamentos?.length,
            startDate,
            endDate
        });
        return 0;
    }
};

/**
 * Calcular próximo horário de dose
 */
function calculateNextDoseTimeJS(med) {
    try {
        if (!med) {
            return null;
        }
        
        if (med.isUsoEsporadico || med.isPaused || !med.horarios || med.horarios.length === 0) {
            return null;
        }
        
        const now = new Date();
        const nowTimestamp = now.getTime();
        const sortedHorarios = [...med.horarios].sort();
        
        // Procurar próxima dose nos próximos 365 dias
        for (let i = 0; i < 365; i++) {
            const checkDate = new Date();
            checkDate.setUTCDate(checkDate.getUTCDate() + i);
            
            if (isMedicationDay(med, checkDate)) {
                for (const horarioStr of sortedHorarios) {
                    const [hour, minute] = horarioStr.split(':').map(Number);
                    
                    if (isNaN(hour) || isNaN(minute)) {
                        continue;
                    }
                    
                    const nextDoseCandidateTimestamp = Date.UTC(
                        checkDate.getUTCFullYear(),
                        checkDate.getUTCMonth(),
                        checkDate.getUTCDate(),
                        hour,
                        minute
                    );
                    
                    if (nextDoseCandidateTimestamp > nowTimestamp) {
                        return new Date(nextDoseCandidateTimestamp);
                    }
                }
            }
        }
        
        return null;
    } catch (error) {
        structuredLogger.error('Erro ao calcular próxima dose', error, {
            medicationId: med?.id
        });
        return null;
    }
}

/**
 * Calcular idade a partir de string de data de nascimento
 */
function calculateAgeFromDobString(dobString) {
    try {
        if (!dobString || typeof dobString !== 'string') {
            return null;
        }
        
        let year, month, day;
        
        if (dobString.includes('/')) {
            [day, month, year] = dobString.split('/');
        } else {
            [year, month, day] = dobString.split('-');
        }
        
        if (!year || !month || !day || year.length < 4) {
            return null;
        }
        
        const birthDate = new Date(Date.UTC(parseInt(year), parseInt(month) - 1, parseInt(day)));
        
        if (isNaN(birthDate.getTime())) {
            return null;
        }
        
        const today = new Date();
        const todayUTC = new Date(Date.UTC(today.getUTCFullYear(), today.getUTCMonth(), today.getUTCDate()));
        
        let age = todayUTC.getUTCFullYear() - birthDate.getUTCFullYear();
        const m = todayUTC.getUTCMonth() - birthDate.getUTCMonth();
        
        if (m < 0 || (m === 0 && todayUTC.getUTCDate() < birthDate.getUTCDate())) {
            age--;
        }
        
        return age;
    } catch (error) {
        structuredLogger.warn("Erro ao calcular idade", { dobString, error: error.message });
        return null;
    }
}

// ============================================================================
// FUNÇÕES DE NOTIFICAÇÃO
// ============================================================================

/**
 * Obter cuidadores que devem ser notificados
 */
async function getCaregiversToNotify(caregiverIds, settingKey) {
    try {
        if (!caregiverIds || caregiverIds.length === 0) {
            return [];
        }
        
        // Validar IDs
        const validIds = caregiverIds.filter(id => id && typeof id === 'string');
        if (validIds.length === 0) {
            return [];
        }
        
        // Firestore tem limite de 10 IDs por query 'in'
        const chunks = [];
        for (let i = 0; i < validIds.length; i += 10) {
            chunks.push(validIds.slice(i, i + 10));
        }
        
        const caregiversToNotify = [];
        
        for (const chunk of chunks) {
            const usersSnapshot = await admin.firestore()
                .collection("users")
                .where(admin.firestore.FieldPath.documentId(), "in", chunk)
                .get();
            
            usersSnapshot.forEach(doc => {
                const data = doc.data();
                if (data && data[settingKey] !== false) {
                    caregiversToNotify.push(doc.id);
                }
            });
        }
        
        return caregiversToNotify;
    } catch (error) {
        structuredLogger.error('Erro ao buscar cuidadores para notificar', error, {
            caregiverIds,
            settingKey
        });
        return [];
    }
}

/**
 * Enviar notificação para múltiplos cuidadores
 */
async function sendNotificationToCaregivers(caregiverIds, payload) {
    try {
        if (!caregiverIds || caregiverIds.length === 0) {
            structuredLogger.warn("Nenhum ID de cuidador fornecido para notificação.");
            return { success: 0, failure: 0 };
        }
        
        if (!payload || !payload.notification) {
            throw new Error('Payload de notificação inválido');
        }
        
        // Validar IDs
        const validIds = caregiverIds.filter(id => id && typeof id === 'string');
        if (validIds.length === 0) {
            return { success: 0, failure: 0 };
        }
        
        // Buscar tokens em chunks (limite do Firestore)
        const chunks = [];
        for (let i = 0; i < validIds.length; i += 10) {
            chunks.push(validIds.slice(i, i + 10));
        }
        
        const tokens = [];
        const userTokensMap = new Map();
        
        for (const chunk of chunks) {
            const usersSnapshot = await admin.firestore()
                .collection("users")
                .where(admin.firestore.FieldPath.documentId(), "in", chunk)
                .get();
            
            usersSnapshot.forEach((doc) => {
                const fcmToken = doc.data()?.fcmToken;
                if (fcmToken && typeof fcmToken === 'string') {
                    tokens.push(fcmToken);
                    userTokensMap.set(fcmToken, doc.id);
                } else {
                    structuredLogger.warn(`Cuidador ${doc.id} não possui um token FCM válido.`);
                }
            });
        }
        
        if (tokens.length === 0) {
            structuredLogger.warn('Nenhum token FCM válido encontrado');
            return { success: 0, failure: 0 };
        }
        
        // Remover tokens duplicados
        const uniqueTokens = [...new Set(tokens)];
        
        const message = { 
            ...payload, 
            tokens: uniqueTokens,
            android: {
                priority: 'high',
                ...payload.android
            }
        };
        
        const response = await admin.messaging().sendEachForMulticast(message);
        
        structuredLogger.info(`Notificações enviadas`, {
            success: response.successCount,
            failure: response.failureCount,
            total: uniqueTokens.length
        });
        
        // Limpar tokens inválidos
        if (response.failureCount > 0) {
            const tokensToDelete = [];
            
            response.responses.forEach((resp, idx) => {
                if (!resp.success) {
                    const errorCode = resp.error?.code;
                    if (errorCode === 'messaging/registration-token-not-registered' || 
                        errorCode === 'messaging/invalid-registration-token') {
                        const failedToken = uniqueTokens[idx];
                        tokensToDelete.push(failedToken);
                        const userId = userTokensMap.get(failedToken);
                        structuredLogger.warn(`Token inválido detectado`, {
                            userId,
                            errorCode
                        });
                    }
                }
            });
            
            if (tokensToDelete.length > 0) {
                await cleanupInvalidTokens(tokensToDelete, userTokensMap);
            }
        }
        
        return {
            success: response.successCount,
            failure: response.failureCount
        };
        
    } catch (error) {
        structuredLogger.error("Erro ao enviar notificações", error, {
            caregiverCount: caregiverIds?.length
        });
        throw error;
    }
}

/**
 * Limpar tokens FCM inválidos do Firestore
 */
async function cleanupInvalidTokens(tokens, userTokensMap) {
    try {
        const batch = admin.firestore().batch();
        let batchCount = 0;
        
        for (const token of tokens) {
            const userId = userTokensMap.get(token);
            if (userId) {
                const userRef = admin.firestore().collection('users').doc(userId);
                batch.update(userRef, { 
                    fcmToken: admin.firestore.FieldValue.delete() 
                });
                batchCount++;
                
                // Firestore batch tem limite de 500 operações
                if (batchCount >= 500) {
                    await batch.commit();
                    batchCount = 0;
                }
            }
        }
        
        if (batchCount > 0) {
            await batch.commit();
        }
        
        structuredLogger.info(`Tokens inválidos removidos`, {
            count: tokens.length
        });
    } catch (error) {
        structuredLogger.error('Erro ao limpar tokens inválidos', error);
    }
}


// ============================================================================
// CLOUD FUNCTIONS - BILLING E COMPRAS
// ============================================================================

/**
 * Verificar compra do Google Play
 * Melhorias: validação robusta, retry logic, logging detalhado
 */
exports.verifyPurchase = onCall(
    {
        region: 'southamerica-east1',
        memory: '256MiB',
        timeoutSeconds: 60,
        maxInstances: 100
    },
    asyncErrorHandler(async (request) => {
        const userId = validateAuth(request);
        
        // Rate limiting
        checkRateLimit(userId, 'verifyPurchase', 5, 60000);
        
        const { purchaseToken, productId, subscriptionId } = request.data;
        
        // Validações
        validators.isNotEmpty(purchaseToken, 'purchaseToken');
        
        if (!productId && !subscriptionId) {
            throw new AppError('invalid-argument', 'productId ou subscriptionId deve ser fornecido');
        }
        
        structuredLogger.info('Verificando compra', {
            userId,
            productId,
            subscriptionId
        });
        
        try {
            // Inicializar API do Google Play
            await retryOperation(() => initGooglePlayPublisher(), 3, 1000);
            
            let purchaseData;
            let isValid = false;
            let expiryDate = null;
            
            // Verificar assinatura
            if (subscriptionId) {
                const response = await retryOperation(async () => {
                    return await publisher.purchases.subscriptions.get({
                        packageName: ANDROID_PACKAGE_NAME,
                        subscriptionId: subscriptionId,
                        token: purchaseToken,
                    });
                }, 3, 1000);
                
                purchaseData = response.data;
                
                // Validar estado da assinatura
                const paymentState = parseInt(purchaseData.paymentState);
                const expiryTimeMillis = parseInt(purchaseData.expiryTimeMillis);
                
                isValid = paymentState === 1 && expiryTimeMillis > Date.now();
                expiryDate = new Date(expiryTimeMillis);
                
                structuredLogger.info('Assinatura verificada', {
                    userId,
                    subscriptionId,
                    isValid,
                    expiryDate,
                    paymentState
                });
            }
            // Verificar compra única
            else if (productId) {
                const response = await retryOperation(async () => {
                    return await publisher.purchases.products.get({
                        packageName: ANDROID_PACKAGE_NAME,
                        productId: productId,
                        token: purchaseToken,
                    });
                }, 3, 1000);
                
                purchaseData = response.data;
                
                // Validar estado da compra
                const purchaseState = parseInt(purchaseData.purchaseState);
                isValid = purchaseState === 0; // 0 = purchased
                
                structuredLogger.info('Produto verificado', {
                    userId,
                    productId,
                    isValid,
                    purchaseState
                });
            }
            
            // Atualizar Firestore se válido
            if (isValid) {
                const updateData = {
                    premium: true,
                    premiumSince: admin.firestore.FieldValue.serverTimestamp(),
                    lastPurchaseVerification: admin.firestore.FieldValue.serverTimestamp(),
                };
                
                if (expiryDate) {
                    updateData.premiumExpiryDate = admin.firestore.Timestamp.fromDate(expiryDate);
                }
                
                if (subscriptionId) {
                    updateData.subscriptionId = subscriptionId;
                }
                
                if (productId) {
                    updateData.lastProductId = productId;
                }
                
                await admin.firestore()
                    .collection('users')
                    .doc(userId)
                    .update(updateData);
                
                // Limpar cache do usuário
                clearCache(userId);
                
                structuredLogger.info('Status premium atualizado', {
                    userId,
                    expiryDate
                });
            }
            
            return {
                success: true,
                isValid,
                expiryDate: expiryDate ? expiryDate.toISOString() : null,
                message: isValid ? 'Compra verificada com sucesso' : 'Compra inválida ou expirada'
            };
            
        } catch (error) {
            structuredLogger.error('Erro ao verificar compra', error, {
                userId,
                productId,
                subscriptionId
            });
            
            // Não falhar silenciosamente - informar o usuário
            throw new AppError('internal', 
                'Não foi possível verificar a compra. Tente novamente em alguns instantes.',
                { originalError: error.message }
            );
        }
    })
);

/**
 * Webhook para notificações do Google Play
 */
exports.handlePlayBillingNotification = onMessagePublished(
    {
        topic: 'play-billing',
        region: 'southamerica-east1',
        memory: '256MiB'
    },
    asyncErrorHandler(async (event) => {
        try {
            const message = event.data.message;
            const data = message.data ? JSON.parse(Buffer.from(message.data, 'base64').toString()) : null;
            
            if (!data || !data.subscriptionNotification) {
                structuredLogger.warn('Notificação de billing inválida', { data });
                return;
            }
            
            const notification = data.subscriptionNotification;
            const { subscriptionId, purchaseToken, notificationType } = notification;
            
            structuredLogger.info('Notificação de billing recebida', {
                subscriptionId,
                notificationType
            });
            
            // Tipos de notificação:
            // 1 = SUBSCRIPTION_RECOVERED
            // 2 = SUBSCRIPTION_RENEWED
            // 3 = SUBSCRIPTION_CANCELED
            // 4 = SUBSCRIPTION_PURCHASED
            // 5 = SUBSCRIPTION_ON_HOLD
            // 6 = SUBSCRIPTION_IN_GRACE_PERIOD
            // 7 = SUBSCRIPTION_RESTARTED
            // 8 = SUBSCRIPTION_PRICE_CHANGE_CONFIRMED
            // 9 = SUBSCRIPTION_DEFERRED
            // 10 = SUBSCRIPTION_PAUSED
            // 11 = SUBSCRIPTION_PAUSE_SCHEDULE_CHANGED
            // 12 = SUBSCRIPTION_REVOKED
            // 13 = SUBSCRIPTION_EXPIRED
            
            // Buscar usuário com este purchaseToken
            const usersSnapshot = await admin.firestore()
                .collection('users')
                .where('lastPurchaseToken', '==', purchaseToken)
                .limit(1)
                .get();
            
            if (usersSnapshot.empty) {
                structuredLogger.warn('Usuário não encontrado para purchaseToken', { purchaseToken });
                return;
            }
            
            const userDoc = usersSnapshot.docs[0];
            const userId = userDoc.id;
            
            // Processar baseado no tipo de notificação
            const updateData = {
                lastBillingNotification: admin.firestore.FieldValue.serverTimestamp(),
                lastBillingNotificationType: notificationType
            };
            
            // Assinatura ativa
            if ([1, 2, 4, 7, 8].includes(notificationType)) {
                updateData.premium = true;
                
                // Verificar detalhes da assinatura
                await initGooglePlayPublisher();
                const response = await publisher.purchases.subscriptions.get({
                    packageName: ANDROID_PACKAGE_NAME,
                    subscriptionId: subscriptionId,
                    token: purchaseToken,
                });
                
                const expiryTimeMillis = parseInt(response.data.expiryTimeMillis);
                updateData.premiumExpiryDate = admin.firestore.Timestamp.fromMillis(expiryTimeMillis);
            }
            // Assinatura cancelada/expirada/revogada
            else if ([3, 12, 13].includes(notificationType)) {
                updateData.premium = false;
                updateData.premiumCanceledAt = admin.firestore.FieldValue.serverTimestamp();
            }
            // Assinatura em período de graça ou pausada
            else if ([5, 6, 10].includes(notificationType)) {
                // Manter premium ativo durante período de graça
                updateData.premiumOnHold = true;
            }
            
            await admin.firestore()
                .collection('users')
                .doc(userId)
                .update(updateData);
            
            clearCache(userId);
            
            structuredLogger.info('Status de assinatura atualizado', {
                userId,
                notificationType,
                premium: updateData.premium
            });
            
        } catch (error) {
            structuredLogger.error('Erro ao processar notificação de billing', error);
            // Não lançar erro - Pub/Sub fará retry automaticamente
        }
    })
);

// ============================================================================
// CLOUD FUNCTIONS - DADOS E ANALYTICS
// ============================================================================

/**
 * Gerar relatório de aderência (Premium)
 */
exports.generateAdherenceReport = onCall(
    {
        region: 'southamerica-east1',
        memory: '512MiB',
        timeoutSeconds: 120,
        maxInstances: 50
    },
    asyncErrorHandler(async (request) => {
        const userId = validateAuth(request);
        
        // Validar premium
        await validatePremiumUser(userId);
        
        // Rate limiting
        checkRateLimit(userId, 'generateReport', 3, 3600000); // 3 por hora
        
        const { dependentId, startDate, endDate, format = 'json' } = request.data;
        
        // Validações
        validators.isNotEmpty(dependentId, 'dependentId');
        validators.isValidDate(startDate, 'startDate');
        validators.isValidDate(endDate, 'endDate');
        
        structuredLogger.info('Gerando relatório de aderência', {
            userId,
            dependentId,
            startDate,
            endDate,
            format
        });
        
        try {
            // Buscar medicamentos
            const medsSnapshot = await admin.firestore()
                .collection('medicamentos')
                .where('userId', '==', dependentId)
                .where('isArchived', '==', false)
                .get();
            
            const medications = [];
            medsSnapshot.forEach(doc => {
                medications.push({ id: doc.id, ...doc.data() });
            });
            
            // Buscar histórico de doses
            const historySnapshot = await admin.firestore()
                .collection('doseHistory')
                .where('userId', '==', dependentId)
                .where('timestamp', '>=', admin.firestore.Timestamp.fromDate(new Date(startDate)))
                .where('timestamp', '<=', admin.firestore.Timestamp.fromDate(new Date(endDate)))
                .get();
            
            const doseHistory = [];
            historySnapshot.forEach(doc => {
                doseHistory.push({ id: doc.id, ...doc.data() });
            });
            
            // Calcular métricas
            const expectedDoses = calculateExpectedDosesForPeriod(medications, startDate, endDate);
            const takenDoses = doseHistory.filter(d => d.status === 'TAKEN').length;
            const missedDoses = doseHistory.filter(d => d.status === 'MISSED').length;
            const adherenceRate = expectedDoses > 0 ? (takenDoses / expectedDoses) * 100 : 0;
            
            // Análise por medicamento
            const medicationAnalysis = medications.map(med => {
                const medExpected = calculateExpectedDosesForMedication(med, new Date(startDate), new Date(endDate));
                const medTaken = doseHistory.filter(d => 
                    d.medicationId === med.id && d.status === 'TAKEN'
                ).length;
                const medMissed = doseHistory.filter(d => 
                    d.medicationId === med.id && d.status === 'MISSED'
                ).length;
                
                return {
                    medicationId: med.id,
                    medicationName: med.nome,
                    expected: medExpected,
                    taken: medTaken,
                    missed: medMissed,
                    adherenceRate: medExpected > 0 ? (medTaken / medExpected) * 100 : 0
                };
            });
            
            // Análise temporal (por dia)
            const dailyAnalysis = {};
            const start = new Date(startDate);
            const end = new Date(endDate);
            
            for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
                const dateKey = d.toISOString().split('T')[0];
                const dayExpected = calculateExpectedDosesForPeriod(medications, d, d);
                const dayTaken = doseHistory.filter(h => {
                    const hDate = h.timestamp.toDate().toISOString().split('T')[0];
                    return hDate === dateKey && h.status === 'TAKEN';
                }).length;
                
                dailyAnalysis[dateKey] = {
                    expected: dayExpected,
                    taken: dayTaken,
                    adherenceRate: dayExpected > 0 ? (dayTaken / dayExpected) * 100 : 0
                };
            }
            
            const report = {
                generatedAt: new Date().toISOString(),
                period: { startDate, endDate },
                dependentId,
                summary: {
                    totalMedications: medications.length,
                    expectedDoses,
                    takenDoses,
                    missedDoses,
                    adherenceRate: Math.round(adherenceRate * 100) / 100
                },
                medicationAnalysis,
                dailyAnalysis,
                insights: generateInsights(adherenceRate, medicationAnalysis, dailyAnalysis)
            };
            
            // Salvar relatório no Firestore
            const reportRef = await admin.firestore()
                .collection('reports')
                .add({
                    userId,
                    dependentId,
                    type: 'adherence',
                    data: report,
                    createdAt: admin.firestore.FieldValue.serverTimestamp()
                });
            
            structuredLogger.info('Relatório gerado com sucesso', {
                userId,
                reportId: reportRef.id,
                adherenceRate
            });
            
            return {
                success: true,
                reportId: reportRef.id,
                report
            };
            
        } catch (error) {
            structuredLogger.error('Erro ao gerar relatório', error, {
                userId,
                dependentId
            });
            throw new AppError('internal', 'Não foi possível gerar o relatório');
        }
    })
);

/**
 * Gerar insights baseados nos dados de aderência
 */
function generateInsights(adherenceRate, medicationAnalysis, dailyAnalysis) {
    const insights = [];
    
    // Insight de aderência geral
    if (adherenceRate >= 90) {
        insights.push({
            type: 'positive',
            category: 'adherence',
            message: 'Excelente aderência! Continue assim!',
            icon: '🎉'
        });
    } else if (adherenceRate >= 70) {
        insights.push({
            type: 'warning',
            category: 'adherence',
            message: 'Boa aderência, mas há espaço para melhorias.',
            icon: '⚠️'
        });
    } else {
        insights.push({
            type: 'alert',
            category: 'adherence',
            message: 'Aderência abaixo do ideal. Considere ajustar lembretes.',
            icon: '🚨'
        });
    }
    
    // Medicamentos com baixa aderência
    const lowAdherenceMeds = medicationAnalysis.filter(m => m.adherenceRate < 70);
    if (lowAdherenceMeds.length > 0) {
        insights.push({
            type: 'alert',
            category: 'medication',
            message: `${lowAdherenceMeds.length} medicamento(s) com aderência abaixo de 70%`,
            medications: lowAdherenceMeds.map(m => m.medicationName),
            icon: '💊'
        });
    }
    
    // Padrão de dias da semana
    const dayOfWeekAnalysis = {};
    Object.entries(dailyAnalysis).forEach(([date, data]) => {
        const dayOfWeek = new Date(date).getDay();
        if (!dayOfWeekAnalysis[dayOfWeek]) {
            dayOfWeekAnalysis[dayOfWeek] = { total: 0, count: 0 };
        }
        dayOfWeekAnalysis[dayOfWeek].total += data.adherenceRate;
        dayOfWeekAnalysis[dayOfWeek].count++;
    });
    
    const dayNames = ['Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado'];
    let worstDay = null;
    let worstRate = 100;
    
    Object.entries(dayOfWeekAnalysis).forEach(([day, data]) => {
        const avgRate = data.total / data.count;
        if (avgRate < worstRate) {
            worstRate = avgRate;
            worstDay = dayNames[day];
        }
    });
    
    if (worstDay && worstRate < 70) {
        insights.push({
            type: 'info',
            category: 'pattern',
            message: `${worstDay} tem a menor aderência (${Math.round(worstRate)}%)`,
            suggestion: 'Considere lembretes extras neste dia',
            icon: '📅'
        });
    }
    
    return insights;
}


// ============================================================================
// CLOUD FUNCTIONS - SCHEDULED JOBS
// ============================================================================

/**
 * Job agendado para verificar assinaturas expiradas
 * Executa diariamente às 3h da manhã (horário de Brasília)
 */
exports.checkExpiredSubscriptions = onSchedule(
    {
        schedule: '0 3 * * *',
        timeZone: 'America/Sao_Paulo',
        region: 'southamerica-east1',
        memory: '512MiB'
    },
    asyncErrorHandler(async (event) => {
        structuredLogger.info('Iniciando verificação de assinaturas expiradas');
        
        try {
            const now = admin.firestore.Timestamp.now();
            
            // Buscar usuários premium com data de expiração
            const expiredUsersSnapshot = await admin.firestore()
                .collection('users')
                .where('premium', '==', true)
                .where('premiumExpiryDate', '<=', now)
                .get();
            
            if (expiredUsersSnapshot.empty) {
                structuredLogger.info('Nenhuma assinatura expirada encontrada');
                return;
            }
            
            const batch = admin.firestore().batch();
            let count = 0;
            
            expiredUsersSnapshot.forEach(doc => {
                batch.update(doc.ref, {
                    premium: false,
                    premiumExpiredAt: admin.firestore.FieldValue.serverTimestamp()
                });
                count++;
                
                // Limpar cache
                clearCache(doc.id);
            });
            
            await batch.commit();
            
            structuredLogger.info('Assinaturas expiradas processadas', { count });
            
        } catch (error) {
            structuredLogger.error('Erro ao verificar assinaturas expiradas', error);
        }
    })
);

/**
 * Job agendado para limpar cache
 * Executa a cada hora
 */
exports.cleanupCache = onSchedule(
    {
        schedule: '0 * * * *',
        region: 'southamerica-east1',
        memory: '128MiB'
    },
    asyncErrorHandler(async (event) => {
        structuredLogger.info('Limpando cache expirado');
        
        const now = Date.now();
        let cleaned = 0;
        
        for (const [key, value] of cache.entries()) {
            if (now - value.timestamp > CACHE_TTL) {
                cache.delete(key);
                cleaned++;
            }
        }
        
        structuredLogger.info('Cache limpo', { 
            cleaned,
            remaining: cache.size 
        });
    })
);

/**
 * Job agendado para gerar insights diários
 * Executa diariamente às 8h da manhã
 */
exports.generateDailyInsights = onSchedule(
    {
        schedule: '0 8 * * *',
        timeZone: 'America/Sao_Paulo',
        region: 'southamerica-east1',
        memory: '512MiB',
        timeoutSeconds: 300
    },
    asyncErrorHandler(async (event) => {
        structuredLogger.info('Gerando insights diários');
        
        try {
            // Buscar usuários premium ativos
            const usersSnapshot = await admin.firestore()
                .collection('users')
                .where('premium', '==', true)
                .where('dailyInsightsEnabled', '==', true)
                .get();
            
            if (usersSnapshot.empty) {
                structuredLogger.info('Nenhum usuário com insights diários habilitados');
                return;
            }
            
            let processed = 0;
            const batch = admin.firestore().batch();
            
            for (const userDoc of usersSnapshot.docs) {
                try {
                    const userId = userDoc.id;
                    
                    // Buscar dependentes do usuário
                    const dependentsSnapshot = await admin.firestore()
                        .collection('dependentes')
                        .where('caregiverId', '==', userId)
                        .get();
                    
                    for (const depDoc of dependentsSnapshot.docs) {
                        const depId = depDoc.id;
                        
                        // Gerar insight para cada dependente
                        const yesterday = new Date();
                        yesterday.setDate(yesterday.getDate() - 1);
                        yesterday.setHours(0, 0, 0, 0);
                        
                        const today = new Date();
                        today.setHours(0, 0, 0, 0);
                        
                        // Buscar dados de ontem
                        const historySnapshot = await admin.firestore()
                            .collection('doseHistory')
                            .where('userId', '==', depId)
                            .where('timestamp', '>=', admin.firestore.Timestamp.fromDate(yesterday))
                            .where('timestamp', '<', admin.firestore.Timestamp.fromDate(today))
                            .get();
                        
                        const taken = historySnapshot.docs.filter(d => d.data().status === 'TAKEN').length;
                        const missed = historySnapshot.docs.filter(d => d.data().status === 'MISSED').length;
                        const total = taken + missed;
                        const adherenceRate = total > 0 ? (taken / total) * 100 : 0;
                        
                        // Criar insight
                        const insightRef = admin.firestore().collection('insights').doc();
                        batch.set(insightRef, {
                            userId,
                            dependentId: depId,
                            date: admin.firestore.Timestamp.fromDate(yesterday),
                            type: 'daily_summary',
                            data: {
                                taken,
                                missed,
                                total,
                                adherenceRate
                            },
                            message: generateDailyMessage(adherenceRate, taken, missed),
                            createdAt: admin.firestore.FieldValue.serverTimestamp()
                        });
                    }
                    
                    processed++;
                    
                } catch (error) {
                    structuredLogger.error('Erro ao gerar insight para usuário', error, {
                        userId: userDoc.id
                    });
                }
            }
            
            await batch.commit();
            
            structuredLogger.info('Insights diários gerados', { processed });
            
        } catch (error) {
            structuredLogger.error('Erro ao gerar insights diários', error);
        }
    })
);

/**
 * Gerar mensagem diária baseada na aderência
 */
function generateDailyMessage(adherenceRate, taken, missed) {
    if (adherenceRate === 100) {
        return `🎉 Perfeito! Todas as ${taken} doses foram tomadas ontem!`;
    } else if (adherenceRate >= 90) {
        return `👍 Muito bem! ${taken} doses tomadas, apenas ${missed} perdida(s).`;
    } else if (adherenceRate >= 70) {
        return `⚠️ Atenção: ${missed} dose(s) perdida(s) ontem. Vamos melhorar hoje!`;
    } else {
        return `🚨 Alerta: Apenas ${taken} de ${taken + missed} doses foram tomadas ontem.`;
    }
}

// ============================================================================
// CLOUD FUNCTIONS - BACKUP E EXPORTAÇÃO
// ============================================================================

/**
 * Exportar dados do usuário (GDPR compliance)
 */
exports.exportUserData = onCall(
    {
        region: 'southamerica-east1',
        memory: '512MiB',
        timeoutSeconds: 300,
        maxInstances: 10
    },
    asyncErrorHandler(async (request) => {
        const userId = validateAuth(request);
        
        // Rate limiting - 1 exportação por dia
        checkRateLimit(userId, 'exportData', 1, 86400000);
        
        const { format = 'json', includeImages = false } = request.data;
        
        structuredLogger.info('Exportando dados do usuário', {
            userId,
            format,
            includeImages
        });
        
        try {
            const exportData = {
                exportedAt: new Date().toISOString(),
                userId,
                user: {},
                dependents: [],
                medications: [],
                doseHistory: [],
                documents: [],
                schedules: [],
                notes: [],
                wellbeing: {}
            };
            
            // Dados do usuário
            const userDoc = await admin.firestore().collection('users').doc(userId).get();
            if (userDoc.exists) {
                exportData.user = userDoc.data();
            }
            
            // Dependentes
            const dependentsSnapshot = await admin.firestore()
                .collection('dependentes')
                .where('caregiverId', '==', userId)
                .get();
            
            dependentsSnapshot.forEach(doc => {
                exportData.dependents.push({ id: doc.id, ...doc.data() });
            });
            
            // Medicamentos
            const medsSnapshot = await admin.firestore()
                .collection('medicamentos')
                .where('userId', '==', userId)
                .get();
            
            medsSnapshot.forEach(doc => {
                exportData.medications.push({ id: doc.id, ...doc.data() });
            });
            
            // Histórico de doses
            const historySnapshot = await admin.firestore()
                .collection('doseHistory')
                .where('userId', '==', userId)
                .orderBy('timestamp', 'desc')
                .limit(10000) // Limitar para evitar timeout
                .get();
            
            historySnapshot.forEach(doc => {
                exportData.doseHistory.push({ id: doc.id, ...doc.data() });
            });
            
            // Documentos
            const docsSnapshot = await admin.firestore()
                .collection('documentos')
                .where('userId', '==', userId)
                .get();
            
            docsSnapshot.forEach(doc => {
                const docData = { id: doc.id, ...doc.data() };
                if (!includeImages) {
                    delete docData.imageUrl;
                }
                exportData.documents.push(docData);
            });
            
            // Agendamentos
            const schedulesSnapshot = await admin.firestore()
                .collection('agendamentos')
                .where('userId', '==', userId)
                .get();
            
            schedulesSnapshot.forEach(doc => {
                exportData.schedules.push({ id: doc.id, ...doc.data() });
            });
            
            // Notas de saúde
            const notesSnapshot = await admin.firestore()
                .collection('healthNotes')
                .where('userId', '==', userId)
                .get();
            
            notesSnapshot.forEach(doc => {
                exportData.notes.push({ id: doc.id, ...doc.data() });
            });
            
            // Dados de bem-estar
            const wellbeingCollections = ['atividades', 'refeicoes', 'hidratacao', 'sono', 'peso'];
            
            for (const collection of wellbeingCollections) {
                const snapshot = await admin.firestore()
                    .collection(collection)
                    .where('userId', '==', userId)
                    .get();
                
                exportData.wellbeing[collection] = [];
                snapshot.forEach(doc => {
                    exportData.wellbeing[collection].push({ id: doc.id, ...doc.data() });
                });
            }
            
            // Salvar arquivo de exportação no Storage
            const fileName = `exports/${userId}/export_${Date.now()}.json`;
            const bucket = admin.storage().bucket();
            const file = bucket.file(fileName);
            
            await file.save(JSON.stringify(exportData, null, 2), {
                contentType: 'application/json',
                metadata: {
                    userId,
                    exportedAt: new Date().toISOString()
                }
            });
            
            // Gerar URL assinada (válida por 7 dias)
            const [url] = await file.getSignedUrl({
                action: 'read',
                expires: Date.now() + 7 * 24 * 60 * 60 * 1000
            });
            
            structuredLogger.info('Dados exportados com sucesso', {
                userId,
                fileName,
                size: JSON.stringify(exportData).length
            });
            
            return {
                success: true,
                downloadUrl: url,
                expiresIn: '7 dias',
                message: 'Dados exportados com sucesso'
            };
            
        } catch (error) {
            structuredLogger.error('Erro ao exportar dados', error, { userId });
            throw new AppError('internal', 'Não foi possível exportar os dados');
        }
    })
);

// ============================================================================
// EXPORTS E DOCUMENTAÇÃO
// ============================================================================

/**
 * Health check endpoint
 */
exports.healthCheck = onRequest(
    {
        region: 'southamerica-east1',
        memory: '128MiB'
    },
    async (req, res) => {
        res.status(200).json({
            status: 'healthy',
            timestamp: new Date().toISOString(),
            version: '2.0.0',
            region: 'southamerica-east1'
        });
    }
);

/**
 * Documentação da API
 */
exports.apiDocs = onRequest(
    {
        region: 'southamerica-east1',
        memory: '128MiB'
    },
    async (req, res) => {
        const docs = {
            version: '2.0.0',
            description: 'NidusCare Cloud Functions API - Enhanced Version',
            endpoints: {
                callable: [
                    {
                        name: 'verifyPurchase',
                        description: 'Verificar compra do Google Play',
                        auth: 'required',
                        rateLimit: '5 requests/minute',
                        params: {
                            purchaseToken: 'string (required)',
                            productId: 'string (optional)',
                            subscriptionId: 'string (optional)'
                        }
                    },
                    {
                        name: 'generateAdherenceReport',
                        description: 'Gerar relatório de aderência (Premium)',
                        auth: 'required',
                        premium: true,
                        rateLimit: '3 requests/hour',
                        params: {
                            dependentId: 'string (required)',
                            startDate: 'string (required)',
                            endDate: 'string (required)',
                            format: 'string (optional, default: json)'
                        }
                    },
                    {
                        name: 'exportUserData',
                        description: 'Exportar dados do usuário (GDPR)',
                        auth: 'required',
                        rateLimit: '1 request/day',
                        params: {
                            format: 'string (optional, default: json)',
                            includeImages: 'boolean (optional, default: false)'
                        }
                    }
                ],
                scheduled: [
                    {
                        name: 'checkExpiredSubscriptions',
                        description: 'Verificar assinaturas expiradas',
                        schedule: 'Daily at 3:00 AM (America/Sao_Paulo)'
                    },
                    {
                        name: 'cleanupCache',
                        description: 'Limpar cache expirado',
                        schedule: 'Every hour'
                    },
                    {
                        name: 'generateDailyInsights',
                        description: 'Gerar insights diários',
                        schedule: 'Daily at 8:00 AM (America/Sao_Paulo)'
                    }
                ],
                http: [
                    {
                        name: 'healthCheck',
                        description: 'Health check endpoint',
                        method: 'GET',
                        auth: 'none'
                    },
                    {
                        name: 'apiDocs',
                        description: 'API documentation',
                        method: 'GET',
                        auth: 'none'
                    }
                ]
            },
            improvements: [
                'Tratamento robusto de erros com try-catch',
                'Logging estruturado e detalhado',
                'Validações de entrada completas',
                'Rate limiting por usuário e ação',
                'Cache em memória com TTL',
                'Retry logic para operações críticas',
                'Limpeza automática de tokens FCM inválidos',
                'Batching para operações em massa',
                'Suporte a GDPR (exportação de dados)',
                'Insights e analytics avançados',
                'Jobs agendados otimizados',
                'Documentação completa'
            ]
        };
        
        res.status(200).json(docs);
    }
);

// ============================================================================
// FIM DO ARQUIVO
// ============================================================================

structuredLogger.info('NidusCare Cloud Functions carregadas com sucesso', {
    version: '2.0.0',
    improvements: 'Tratamento de erros, validações, cache, rate limiting e muito mais'
});

