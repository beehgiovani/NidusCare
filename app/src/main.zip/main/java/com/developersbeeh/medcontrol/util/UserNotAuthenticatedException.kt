package com.developersbeeh.medcontrol.util

class UserNotAuthenticatedException(message: String = "Usuário não autenticado.") : Exception(message)


