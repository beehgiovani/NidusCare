package com.developersbeeh.medcontrol.data.model

// Enum para representar os tipos de medicamento
enum class TipoMedicamento {
    ORAL,
    TOPICO,
    INJETAVEL
}