package com.developersbeeh.medcontrol.util

class InvalidLinkingCodeException(message: String = "Código de vínculo inválido.") : Exception(message)


