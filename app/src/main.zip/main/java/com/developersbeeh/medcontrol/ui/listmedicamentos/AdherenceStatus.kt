    // src/main/java/com/developersbeeh/medcontrol/ui/listmedicamentos/AdherenceStatus.kt
    package com.developersbeeh.medcontrol.ui.listmedicamentos

    enum class AdherenceStatus {
        NORMAL,
        OVERDOSE
    }