package com.developersbeeh.medcontrol.ui.listmedicamentos

enum class MedicamentoStatus {
    ATRASADO,
    PROXIMA_DOSE,
    FINALIZADO,
    SEM_NOTIFICACAO,
    PAUSADO,
    ESPORADICO
}