package com.developersbeeh.medcontrol.ui.analysis

data class AnalysisSection(
    val title: String,
    val content: String
)