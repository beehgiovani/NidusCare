package com.developersbeeh.medcontrol.util

class InvalidIdException : Exception {
    constructor(message: String = "ID inválido.") : super(message)
}


